package com.minahuang.time_tracker_flutter_course

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
